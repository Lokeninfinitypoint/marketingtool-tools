import { ToolInterface } from '@/components/ToolInterface';

export default function CompetitorAdSpy() {
  return (
    <div className="tool-page">
      <h1>Competitor Ad Spy</h1>
      <ToolInterface toolId="competitor-ad-spy" />
    </div>
  );
}

export const metadata = {
  title: 'Competitor Ad Spy - MarketingTool Pro',
  description: 'Professional competitor ad spy for marketing professionals',
};
