#!/bin/bash

echo "🚀 Deploying MarketingTool Pro - Complete Madgicx Clone"
echo "=================================================="

# Create directories
mkdir -p /opt/marketingtool-pro/{wordpress,app,data,nginx}

# Copy files
echo "📁 Copying files..."
cp -r wordpress/* /opt/marketingtool-pro/wordpress/
cp -r app/* /opt/marketingtool-pro/app/
cp -r data/* /opt/marketingtool-pro/data/
cp docker-compose.yml /opt/marketingtool-pro/
cp nginx.conf /opt/marketingtool-pro/

# Import WordPress content
echo "📥 Importing WordPress content..."
cd /opt/marketingtool-pro/wordpress
wp import ../data/content/madgicx-content.xml --authors=create

# Setup databases
echo "🗄️ Setting up databases..."
docker compose up -d postgres redis
sleep 10
docker compose exec postgres psql -U postgres -c "CREATE DATABASE appwrite; CREATE DATABASE windmill;"

# Start all services
echo "🎯 Starting all services..."
docker compose up -d

# Wait for services
echo "⏳ Waiting for services to start..."
sleep 30

# Setup SSL
echo "🔒 Setting up SSL certificates..."
certbot --nginx -d marketingtool.pro -d app.marketingtool.pro -d auth.marketingtool.pro -d wm.marketingtool.pro

echo ""
echo "✅ Deployment Complete!"
echo ""
echo "🌐 Access URLs:"
echo "   Website: https://marketingtool.pro"
echo "   App: https://app.marketingtool.pro"
echo "   Appwrite: https://auth.marketingtool.pro"
echo "   Windmill: https://wm.marketingtool.pro"
echo ""
echo "📊 Total Tools: 811+"
echo "📁 Total Data: 25GB"
echo "🎨 Theme: BrightHub Custom"
echo ""
