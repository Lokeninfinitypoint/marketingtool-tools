import { ToolInterface } from '@/components/ToolInterface';

export default function TikTokVideoAnalyzer() {
  return (
    <div className="tool-page">
      <h1>TikTok Video Analyzer</h1>
      <ToolInterface toolId="tiktok-video-analyzer" />
    </div>
  );
}

export const metadata = {
  title: 'TikTok Video Analyzer - MarketingTool Pro',
  description: 'Professional tiktok video analyzer for marketing professionals',
};
