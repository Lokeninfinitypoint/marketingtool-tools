import { ToolInterface } from '@/components/ToolInterface';

export default function FacebookAdsAudienceAnalyzer() {
  return (
    <div className="tool-page">
      <h1>Facebook Ads Audience Analyzer</h1>
      <ToolInterface toolId="facebook-ads-audience-analyzer" />
    </div>
  );
}

export const metadata = {
  title: 'Facebook Ads Audience Analyzer - MarketingTool Pro',
  description: 'Professional facebook ads audience analyzer for marketing professionals',
};
