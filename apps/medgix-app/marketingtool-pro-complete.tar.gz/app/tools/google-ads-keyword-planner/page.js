import { ToolInterface } from '@/components/ToolInterface';

export default function GoogleAdsKeywordPlanner() {
  return (
    <div className="tool-page">
      <h1>Google Ads Keyword Planner</h1>
      <ToolInterface toolId="google-ads-keyword-planner" />
    </div>
  );
}

export const metadata = {
  title: 'Google Ads Keyword Planner - MarketingTool Pro',
  description: 'Professional google ads keyword planner for marketing professionals',
};
