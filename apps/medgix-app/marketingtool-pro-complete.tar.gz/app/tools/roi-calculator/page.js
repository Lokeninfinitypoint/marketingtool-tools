import { ToolInterface } from '@/components/ToolInterface';

export default function ROICalculator() {
  return (
    <div className="tool-page">
      <h1>ROI Calculator</h1>
      <ToolInterface toolId="roi-calculator" />
    </div>
  );
}

export const metadata = {
  title: 'ROI Calculator - MarketingTool Pro',
  description: 'Professional roi calculator for marketing professionals',
};
