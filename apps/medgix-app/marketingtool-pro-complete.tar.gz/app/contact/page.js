export default function Contact() {
  return (
    <div className="page">
      <h1>Contact</h1>
      <p>Content for contact page.</p>
    </div>
  );
}
