export default function Pricing() {
  return (
    <div className="page">
      <h1>Pricing</h1>
      <p>Content for pricing page.</p>
    </div>
  );
}
