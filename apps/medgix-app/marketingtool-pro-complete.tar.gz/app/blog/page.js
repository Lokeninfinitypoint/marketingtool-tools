export default function Blog() {
  return (
    <div className="page">
      <h1>Blog</h1>
      <p>Content for blog page.</p>
    </div>
  );
}
