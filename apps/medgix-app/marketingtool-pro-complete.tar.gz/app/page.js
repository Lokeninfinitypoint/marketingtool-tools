export default function Home() {
  return (
    <div className="page">
      <h1>Home</h1>
      <p>Content for home page.</p>
    </div>
  );
}
