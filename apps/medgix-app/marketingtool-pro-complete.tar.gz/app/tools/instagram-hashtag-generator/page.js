import { ToolInterface } from '@/components/ToolInterface';

export default function InstagramHashtagGenerator() {
  return (
    <div className="tool-page">
      <h1>Instagram Hashtag Generator</h1>
      <ToolInterface toolId="instagram-hashtag-generator" />
    </div>
  );
}

export const metadata = {
  title: 'Instagram Hashtag Generator - MarketingTool Pro',
  description: 'Professional instagram hashtag generator for marketing professionals',
};
