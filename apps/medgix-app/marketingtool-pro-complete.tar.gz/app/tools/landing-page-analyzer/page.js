import { ToolInterface } from '@/components/ToolInterface';

export default function LandingPageAnalyzer() {
  return (
    <div className="tool-page">
      <h1>Landing Page Analyzer</h1>
      <ToolInterface toolId="landing-page-analyzer" />
    </div>
  );
}

export const metadata = {
  title: 'Landing Page Analyzer - MarketingTool Pro',
  description: 'Professional landing page analyzer for marketing professionals',
};
