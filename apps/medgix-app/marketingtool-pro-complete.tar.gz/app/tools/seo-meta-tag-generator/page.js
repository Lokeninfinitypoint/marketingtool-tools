import { ToolInterface } from '@/components/ToolInterface';

export default function SEOMetaTagGenerator() {
  return (
    <div className="tool-page">
      <h1>SEO Meta Tag Generator</h1>
      <ToolInterface toolId="seo-meta-tag-generator" />
    </div>
  );
}

export const metadata = {
  title: 'SEO Meta Tag Generator - MarketingTool Pro',
  description: 'Professional seo meta tag generator for marketing professionals',
};
