import { ToolInterface } from '@/components/ToolInterface';

export default function LinkedInPostOptimizer() {
  return (
    <div className="tool-page">
      <h1>LinkedIn Post Optimizer</h1>
      <ToolInterface toolId="linkedin-post-optimizer" />
    </div>
  );
}

export const metadata = {
  title: 'LinkedIn Post Optimizer - MarketingTool Pro',
  description: 'Professional linkedin post optimizer for marketing professionals',
};
