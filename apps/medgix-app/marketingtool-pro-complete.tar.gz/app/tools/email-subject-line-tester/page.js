import { ToolInterface } from '@/components/ToolInterface';

export default function EmailSubjectLineTester() {
  return (
    <div className="tool-page">
      <h1>Email Subject Line Tester</h1>
      <ToolInterface toolId="email-subject-line-tester" />
    </div>
  );
}

export const metadata = {
  title: 'Email Subject Line Tester - MarketingTool Pro',
  description: 'Professional email subject line tester for marketing professionals',
};
