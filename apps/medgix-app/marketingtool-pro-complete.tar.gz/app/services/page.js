export default function Services() {
  return (
    <div className="page">
      <h1>Services</h1>
      <p>Content for services page.</p>
    </div>
  );
}
